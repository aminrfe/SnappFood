import React, { useState } from "react";
import { Box, TextField, Button, Typography, IconButton, InputAdornment, FormControl, OutlinedInput, InputLabel, Input } from "@mui/material";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import LoginImg from "../assets/imgs/login.png"
import PhoneEnabledIcon from '@mui/icons-material/PhoneEnabled';
import KeyIcon from '@mui/icons-material/Key';

function Login({ onSwitch }) {
  const [showPassword, setShowPassword] = useState(false);

  const handleClickShowPassword = () => {
    setShowPassword((show) => !show);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };

  return (
    <div className="login-container">
      <img
        src={LoginImg}
        alt="Login Illustration"
        style={{ width: "100%", marginBottom: "20px" }}
      />

      <Box sx={{ display: 'flex', alignItems: 'flex-end'}} marginBottom={0.9} >
        <PhoneEnabledIcon sx={{ color: 'action.active', mr: 1, mb: 2 }} />
        <TextField fullWidth type="tel" id="input-with-sx" label="شماره موبایل" variant="standard" margin="normal" />
      </Box>
      
      <Box sx={{ display: 'flex', alignItems: 'flex-end'}}>
        <KeyIcon sx={{ color: 'action.active', mr: 1, mb: 2 }} />
        <FormControl sx={{ m: 1}} variant="standard" fullWidth>
            <InputLabel htmlFor="standard-adornment-password">رمزعبور</InputLabel>
            <Input
            fullWidth
              id="standard-adornment-password"
              type={showPassword ? 'text' : 'password'}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    aria-label={
                      showPassword ? 'hide the password' : 'display the password'
                    }
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    // onMouseUp={handleMouseUpPassword}
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              }
            />
          </FormControl>
        </Box>

      <Button variant="contained" color="primary" fullWidth>
        ورود
      </Button>

      
      <Typography
        variant="body2"
        onClick={onSwitch}
      >
        حساب کاربری ندارید؟ ثبت‌نام
      </Typography>
    </div>
  );
}

export default Login;